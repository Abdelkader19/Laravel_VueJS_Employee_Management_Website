<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Responsable_RH extends Model
{
    use HasFactory;

    protected $fillable=[
        "prénom",
        "nom"

    ];

    public function Employes() 
    {
    return $this->hasMany(Employe::class);
    }
    

}
