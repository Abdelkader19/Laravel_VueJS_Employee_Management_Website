<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Conge extends Model
{
    use HasFactory;
    protected $fillable=[
        "date_début",
        "date_fin",
        "cause",
        "nb_j_deja_pris",
        "id_employe"  
         ];
         public function Employe()
         {
             return $this->belongsTo(Employe::class,"id_employe"); 
         }
}
