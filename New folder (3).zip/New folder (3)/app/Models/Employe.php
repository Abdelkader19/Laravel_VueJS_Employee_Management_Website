<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employe extends Model
{
    use HasFactory;
   
    protected $table = 'employes';
    
    protected $fillable=[ 
            "Prénom",
            "Nom",
            "Email",
            "Position",
            "Departement",
            "Grade",
            "id_ResponsableRH"
       ];
       public function Responsable_RH()
    {
        return $this->belongsTo(Responsable_RH::class,"id_ResponsableRH"); 
    }

    public function conges()
{
return $this->hasMany(Conge::class); 
} 

}
