<?php

namespace App\Http\Controllers;

use App\Models\Conge;
use Illuminate\Http\Request;

class CongeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $conges = Conge::with('employe')->get();
        return $conges;  
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $conge = new Conge([
            "date_début" => $request->input("date_début"),
            "date_fin" => $request->input("date_fin"),
            "cause" => $request->input("cause"),
            "nb_j_deja_pris" => $request->input("nb_j_deja_pris"),
            "id_employe" => $request->input("id_employe")
            ]); 
            $conge->save();
            return response()->json($conge,201);
       } 
      
    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $conge = Conge::find($id); 
        return response()->json($conge); 

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $conge = Conge::find($id);
        $conge->update($conge->all());
        return response()->json($conge,200); 
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $conge = Conge::find($id);
        $conge->delete();
        return response()->json('congé supprimée !');

    }

    public function showCongeByEmploye($idEmp)
 {
   $conges= Conge::where("id_employe", $idEmp)->with('employes')->get();
   return response()->json($conges); 
   } 
}
