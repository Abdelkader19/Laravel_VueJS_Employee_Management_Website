<?php

namespace App\Http\Controllers;

use App\Models\Responsable_RH;
use Illuminate\Http\Request;

class ResponsableRHController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $respsRH = Responsable_RH::all();
        return $respsRH; 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $respRH= new Responsable_RH ([ 
            "Prénom" => $request->input("Prénom"),
            "Nom" => $request->input("Nom"),
            
           ]);
            $respRH->save();
            return response()->json($respRH, 201); 
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $respRH = Responsable_RH::find($id);
        return response()->json($respRH);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $respRH = Responsable_RH::find($id);
        $respRH->update($request->all());
        return response()->json($respRH, 200);  
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $respRH = Responsable_RH::find($id);
        $respRH->delete();
        return response()->json('responsable RH supprimée !');
    }
}
