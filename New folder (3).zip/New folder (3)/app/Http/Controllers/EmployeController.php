<?php

namespace App\Http\Controllers;

use App\Models\Employe;
use Illuminate\Http\Request;

class EmployeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index() 
    {
        $employes = Employe::all();
        return $employes; 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $employe = new Employe([ 
            "Prénom" => $request->input("Prénom"),
            "Nom" => $request->input("Nom"),
            "Email" => $request->input("Email"),
            "Position" => $request->input("Position"),
            "Departement" => $request->input("Departement"),
            "Grade" => $request->input("Grade"),
            "id_ResponsableRH" => $request->input("id_ResponsableRH")
           ]);
            $employe->save();
            return response()->json($employe, 201); 
         }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {  
        $employe = Employe::find($id);
        return response()->json($employe);

   }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $employe = Employe::find($id);
        $employe->update($request->all());
        return response()->json($employe, 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $employe = Employe::find($id);
        $employe->delete();
        return response()->json('Employe supprimée !');
    }
}
