<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employes', function (Blueprint $table) {
            $table->id();
            $table->string("Prénom",50);
            $table->string("Nom",50);
            $table->string("Email",150)->unique(); 
            $table->string("Position",50);
            $table->string("Departement",50);
            $table->string("Grade",50);
            $table->unsignedBigInteger('id_ResponsableRH');
            $table->foreign('id_ResponsableRH')->references('id')->on('responsable__r_h_s')->onDelete('restrict'); 
            $table->timestamps(); 
        });

    }  

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employes');
    }
};
